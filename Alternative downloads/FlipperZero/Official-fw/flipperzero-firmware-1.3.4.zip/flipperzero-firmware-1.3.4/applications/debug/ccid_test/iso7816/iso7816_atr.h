#pragma once

typedef struct {
    uint8_t TS;
    uint8_t T0;
} Iso7816Atr;
