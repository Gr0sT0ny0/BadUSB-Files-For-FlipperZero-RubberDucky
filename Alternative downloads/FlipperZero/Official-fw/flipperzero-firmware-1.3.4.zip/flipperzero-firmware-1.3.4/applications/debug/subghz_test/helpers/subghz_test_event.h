#pragma once

typedef enum {
    //SubGhzTestCustomEvent
    SubGhzTestCustomEventStartId = 100,
    SubGhzTestCustomEventSceneShowOnlyRX,
} SubGhzTestCustomEvent;
